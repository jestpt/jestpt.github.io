invert.matrix <- function(x, tolerance = sqrt(.Machine$double.eps)) {

  # coerce
  x <- as.matrix(x)

  dnx <- dimnames(x)
  if (is.null(dnx)) {
    dnx <- vector("list", 2)
  }

  # singular value decomposition
  SVD <- svd(x)
  V <- SVD$v
  U <- SVD$u
  D <- SVD$d

  # detect non-zero eigen values
  non.zero <- D > tolerance * D[1]

  # compute the inverse of matrix x
  inverse.matrix <- structure(

    if (any(non.zero)) {
      V[, non.zero] %*% (t(U[ , non.zero])/D[non.zero])
    } else {
      x
    }

  , dimnames = dnx[2:1])

  # return
  rout <- unname(inverse.matrix)
  return(rout)

}
