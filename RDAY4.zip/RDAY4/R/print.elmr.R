print.elmr <- function(object) {
  # print for elmr

  cat(toupper("Extreme Learning Machine Regressor\n\n"))
  cat(toupper(paste("Hidden Layer size:", object$HIDDEN.NEURONS, "\n")))
  cat(toupper(paste("Activation function:", object$ACTIVATION, "\n")))
  cat(toupper(paste("SEED:", object$SEED, "\n\n")))

  rmse <- format(round(object$METRICS[1], 3), digits = 4)
  mae <- format(round(object$METRICS[2], 3), digits = 4)
  message.rmse <- toupper(paste("Root Mean Squared Error:", rmse, "\n"))
  message.mae <- toupper(paste("Mean Absolute Error:", mae, "\n"))
  cat(message.rmse)
  cat(message.mae)

}
