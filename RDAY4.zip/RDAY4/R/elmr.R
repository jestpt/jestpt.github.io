elmr <- function(x, y, hidden.n, activation, seed = NULL) {
# fits a extreme learning machine for regression
#
# formal arguments:
# x, features
# y, target
# hidden.n, number of hidden nodes
# activation, activation function

  # set random number generator


  # coerce x and y to be matrices ----------------------------------------------


  # transpose both x and y


  # get number of features (rows) and samples (columns)
  nfeatures <-
  nsamples <-

  # exception handling: make the function stop if x and y do not have the same
  # number of samples

  if (condition) {
    stop("x and y do not have the same number of observations.")
  }

  # ----------------------------------------------------------------------------


  # Extreme Learning Machine (Extremely Easy) ----------------------------------

  # (1) generate, at random, synaptic weights (W) and bias (b) for the the
  # hidden layer with n = hidden.n nodes

  # generate random W
  n.neurons <-
  random.neurons <-

  # populate W and  create b
  W <-
  b <-
  b <-

  # (2) map x to the hidden layer (H) with synaptic weights (W) and biases (b)
  # H = activation(Wx+b)
  H <-

  # (3) solve HB = y to compute the output layer weights (B)
  Hinv <-
  B <-  t(t(Hinv) %*% t(y))

  # Extreme Learning Machine (Extremely Easy) ----------------------------------


  # compute root mean squared error ----------------------------------------

  # yhat = BH
  yhat <-
  rmse <-  sqrt(mean((y - yhat)^2))
  mae <- mean(abs(y - yhat))
  # ----------------------------------------------------------------------------

  # create object of class "elmr" -----------------------------------------------

  # get function call and get activation function as a string
  elm.call <- match.call()
  elm.activation <- as.character(elm.call$activation)
  activation.string <-
    strsplit(elm.activation, split = ".", fixed = TRUE)[[1]][1]

  object <- list(
    W = W,
    b = as.numeric(b[,1]),
    B = unname(B),
    G = activation,
    YHAT = as.numeric(yhat),
    METRICS = c(RMSE = rmse, MAE = mae),
    HIDDEN.NEURONS = hidden.n,
    ACTIVATION = toupper(activation.string),
    SEED = seed
  )

  # attribute class "elmr" to object

  # ----------------------------------------------------------------------------

  # return
  rout <- object
  return(rout)

}
