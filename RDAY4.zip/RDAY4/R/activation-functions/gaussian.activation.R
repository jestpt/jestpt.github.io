gaussian.activation <- function(x) {
  # Gaussian activation function
  # Range (0, 1]
  
  y <- exp(-x^2)
  
  # return
  rout <- y
  return(rout)
  
}