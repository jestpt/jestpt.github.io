sigmoid.activation <- function(x) {
  # Sigmoid activation function
  # Range [0, 1]
  
  y <- 1 / (1 + exp(-x))
  
  # return
  rout <- y
  return(rout)
  
}