softsign.activation <- function(x) {
  # Softsign Activation Function
  # Range [-1, 1]
  
  y <- x / (1 + abs(x))
  
  # return
  rout <- y
  return(rout)
  
}