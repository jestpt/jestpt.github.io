softplus.activation <- function(x) {
  # SoftPlus Activation Function
  # Range (0, Inf)
  
  y <- log(1 + exp(x))
  
  # return
  rout <- y
  return(rout)
  
}