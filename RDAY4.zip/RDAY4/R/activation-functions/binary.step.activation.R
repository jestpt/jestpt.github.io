binary.step.activation <- function(x) {
  # Binary Step function
  # Range [0, 1]

  # Vectorization
  internal.function <- function(x) {

    if (x < 0) {
      y <- 0
    } else {
      y <- 1
    }

    # return
    rout <- y
    return(rout)

  }
  internal.function <- Vectorize(internal.function)

  # apply function
  y <- internal.function(x)

  # return
  rout <- y
  return(rout)

}
