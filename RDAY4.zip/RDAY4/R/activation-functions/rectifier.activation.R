rectifier.activation <- function(x) {
  # Rectifier function
  # Range [0, Inf)

  # Vectorization
  internal.function <- function(x) {

    y <- max(0, x, na.rm = TRUE)

    # return
    rout <- y
    return(rout)

  }
  internal.function <- Vectorize(internal.function)

  # apply function
  y <- internal.function(x)

  # return
  rout <- y
  return(rout)

}
