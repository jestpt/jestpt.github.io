# normalize
normalize <- function(x, y = NULL){
  
  # define normalization function
  normalizer <- function(x, x.min = NULL, x.max = NULL) {
    
    if(is.null(x.min)){
      x.min <- min(x, na.rm = TRUE)
    }
    if(is.null(x.max)){
      x.max <- max(x, na.rm = TRUE)
    }
    
    # normalize
    new.x <- (x-x.min)/(x.max-x.min)
    
    # return
    rout <- new.x
    return(rout)
  }
  
  # normalize all columns
  new.x <- apply(x, 2, normalizer)
  x.min <- apply(x, 2, min, na.rm = TRUE)
  x.max <- apply(x, 2, max, na.rm = TRUE)
  attr(new.x, 'min')  = x.min
  attr(new.x, 'max')  = x.max
  
  if(!is.null(y)){
    x.min <- attr(y, 'min')
    x.max <- attr(y, 'max')
    m <- length(x.min)
    
    if(NCOL(x)!=m){
      stop('number of columns in x do not match columnsl in y.')
    }
    
    new.x <- do.call(cbind, lapply(seq_len(m),function(i){
      normalizer(x[, i], x.min = x.min[i], x.max = x.max[i])
    }))
    
  }
  
  # return
  rout <- new.x
  return(rout)
  
}