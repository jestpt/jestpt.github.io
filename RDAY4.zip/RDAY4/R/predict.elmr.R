predict.elmr <- function(object, newdata) {
  # predict for elmr

  # coerce and transpose new data ----------------------------------------------
  if (is.null(dim(newdata))) {
    newdata <- rbind(newdata)
  } else {
    newdata <- as.matrix(newdata)
  }
  newdata <- t(newdata)
  dimensions <- dim(newdata)
  # ----------------------------------------------------------------------------

  # intialize parameters from object -------------------------------------------
  W <- object$W
  b <- object$b
  b <- matrix(b, nrow = dim(W)[1], ncol = dim(newdata)[2])
  B <- object$B
  G <- object$G
  # ----------------------------------------------------------------------------
  # exception handling ---------------------------------------------------------
  if (dim(W)[2] != dim(newdata)[1]) {
    stop("number of inputs in newdata do not match with trained elmr model")
  }
  # ----------------------------------------------------------------------------

  # apply elm algorith ---------------------------------------------------------
  H <- apply((W %*% newdata) + b, 1:2, G)
  YHAT <- B %*% H
  # ----------------------------------------------------------------------------

  # return
  rout <- as.numeric(YHAT)
  return(rout)

}
