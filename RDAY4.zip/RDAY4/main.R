# code snippet to source all .R files from a directory -------------------------
path.to.files <- "R/activation-functions"
file.names <- dir(path.to.files, full.names = "TRUE", pattern = ".R")
fout <- lapply(file.names, source, echo = FALSE)
rm(fout)
# ------------------------------------------------------------------------------


# source emlr, predict.emlr, and print.elm files -------------------------------

# ------------------------------------------------------------------------------


# load Buckberry and Chamberlain (2002) dataset from RDS file in data folder----
BC <- readRDS("data/buckberry-chamberlain.RDS")

# subset TO, ST, MI, MA, AP as an object named x
predictors <- c('TO', 'ST', 'MI', 'MA', 'AP')
x <- BC[, predictors]
# create an object y from the variable AGE
y <- BC[, "AGE"]
# ------------------------------------------------------------------------------

# train elmr model to predict age-at-death using Buckberry and Chamberlain data-



# ------------------------------------------------------------------------------
