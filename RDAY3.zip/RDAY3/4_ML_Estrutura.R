library(caret)

set.seed(19920804)

# verificar directório antes de avançar

# partir dados em dados-treino e dados-teste

inTraining <- createDataPartition(machinedata$SEX,
																	p = 0.75,
																	list = FALSE)

training <- machinedata[ inTraining,]
testing  <- machinedata[-inTraining,]
testX <- testing[,-1]
testY <- testing[,1]

# validação cruzada

fitControl <- trainControl(method = 'repeatedcv',
													 number = 5,
													 repeats = 2,
													 verboseIter = FALSE)

# treinar modelo

fit <- train(SEX ~ AMB + ASP + LB + PFIe + AAId + LAE, data = training,
						 method = 'nnet',
						 trControl = fitControl,
						 preProc = c('center', 'scale')
)

# Testar resultados:

predictions <- predict(fit, testX)
confusionMatrix(predictions, testY)

# "AMB"  "LB" "PFIe" "ASP" "PFId" "LAE" "AAId" "LS" "AAIe" "DO1E" "LME"  "DIK"