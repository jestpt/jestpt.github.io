library(shiny)
library(caret)
source('./global.R')

# 2 exercícios: Criar modelo de classificação interactivo

function(input, output, session) {
	
	observeEvent(input$processData, {
		
		output$showResults <- reactive({'no'}) 
		
		isolate({
			
			# Reproducibility
			
			if (!is.numeric(input$seed)) {
				output$seed.v <- renderPrint({
					cat(paste('Reproducibility: No seed was selected'))
				})
			}else{
				output$seed.v <- renderPrint({
					cat(paste('Reproducibility: The integer', input$seed, 'was set as your seed.'))
				})
				set.seed(input$seed)
			}
			
			###### Exercício 1
			
			## Aqui vamos criar um modelo
			
			
			######
			
			output$io.model <- renderPrint({
				print(fit)
			})
			
			output$io.varplot <- renderPlot({
				plot(varImp(fit, scale = FALSE), main = 'Ordered variables by importance')
			})
			
			output$io.matrix <- renderPrint({
				###### Exercício 2
				
				## Aqui vão as matrizes de confusão
				
				######
			})
			
			output$io.graphics <- renderPlot({
				trellis.par.set(caretTheme())
				plot(fit, main = 'Overall accuracy across tuning parameters')
			})
			
		})
		output$showResults <- reactive({'yes'})
		
		outputOptions(output, 'showResults', suspendWhenHidden = FALSE)
	})

}