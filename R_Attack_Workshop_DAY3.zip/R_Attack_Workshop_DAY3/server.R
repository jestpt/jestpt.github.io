library(shiny)
library(caret)
source('./global.R')

function(input, output, session) {
	
	observeEvent(input$processData, {
		
		output$showResults <- reactive({'no'}) 
		
		isolate({
			
			# Reproducibility
			
			if (!is.numeric(input$seed)) {
				output$seed.v <- renderPrint({
					cat(paste('Reproducibility: No seed was selected'))
				})
			}else{
				output$seed.v <- renderPrint({
					cat(paste('Reproducibility: The integer', input$seed, 'was set as your seed.'))
				})
				set.seed(input$seed)
			}
			
			inTraining <- createDataPartition(machinedata$SEX,
																				p = input$splitValue,
																				list = FALSE)
			
			training <- machinedata[ inTraining,]
			testing  <- machinedata[-inTraining,]
			testX <- testing[,-1]
			testY <- testing[,1]
			
			fitControl <- trainControl(method = 'repeatedcv',
																 number = input$nFitControl,
																 repeats = input$rFitControl,
																 verboseIter = FALSE)
			fit <- train(SEX ~ AMB + ASP + LB + PFIe + AAId + LAE,
										data = training,
										method = input$classificationModel,
										trControl = fitControl,
										preProc = c('center', 'scale'))
			
			output$io.model <- renderPrint({
				print(fit)
			})
			
			output$io.varplot <- renderPlot({
				plot(varImp(fit, scale = FALSE), main = 'Ordered variables by importance')
			})
			
			output$io.matrix <- renderPrint({
				predictions <- predict(fit, testX)
				confusionMatrix(predictions, testY)
			})
			
			output$io.graphics <- renderPlot({
				trellis.par.set(caretTheme())
				plot(fit, main = 'Overall accuracy across tuning parameters')
			})
			
		})
		output$showResults <- reactive({'yes'})
		
		outputOptions(output, 'showResults', suspendWhenHidden = FALSE)
	})

}