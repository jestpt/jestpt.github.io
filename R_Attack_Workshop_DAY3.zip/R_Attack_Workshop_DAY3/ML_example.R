library(caret)

set.seed(19920804)

# verificar directório antes de avançar

inTraining <- createDataPartition(machinedata$SEX,
																	p = 0.75,
																	list = FALSE)

training <- machinedata[ inTraining,]
testing  <- machinedata[-inTraining,]
testX <- testing[,-1]
testY <- testing[,1]

fitControl <- trainControl(method = 'repeatedcv',
													 number = 5,
													 repeats = 1,
													 verboseIter = FALSE)

fit <- train(SEX ~ AMB + ASP + LB + PFIe + AAId + LAE, data = training,
						 method = 'nnet',
						 trControl = fitControl,
						 preProc = c('center', 'scale')
)

predictions <- predict(fit, testX)
confusionMatrix(predictions, testY)

# "AMB"  "LB"   "PFIe" "ASP"  "PFId" "LAE"  "AAId" "LS"   "AAIe" "DO1E" "LME"  "DIK"