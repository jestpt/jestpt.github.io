library(shiny)

shinyUI(
	fluidPage(
		title = 'Predict',
		hr(),
		fluidRow(
			column(8,
						 h4('Cross-Validation'),
						 hr(),
						 column(6,
						 			 sliderInput('splitValue', label = 'Proportion of training data',
						 			 						min = 0.6, max = 0.9, value = 0.75, step = 0.01)),
						 column(3,
						 			 radioButtons('nFitControl','k-Folds',
						 			 						 choices = c(2, 5, 10),
						 			 						 selected = 5, inline = T)),
						 column(3,
						 			 radioButtons('rFitControl','Repeats (sets of folds)',
						 			 						 choices = c(1, 2, 5, 10),
						 			 						 selected = 1, inline = T))
			),
			column(4,
						 h4('Machine Learning'),
						 hr(),
						 selectInput('classificationModel', 'Classification Model',
						 						choices = model.list)
			)
		),
		hr(),
		fluidRow(
			column(8,
						 h4('Reproducibility'),
						 hr(),
						 column(2,
						 			 numericInput('seed', label = 'Set a Seed', value = FALSE)
						 ),
						 column(10,
						 			 p('Models are pseudo-randomly generated to avoid bias.
						 			 	However, you might want reproducible results, e.g. for publications or reports.
						 			 	Chose any numeric value (i.e. "seed") to generate a reproducible statistical model.')
						 )
			),
			column(4,
						 h4('Perform Analysis'),
						 hr(),
						 htmlOutput('errorMessage.input'),
						 br(),
						 actionButton('processData', 'Process Data')
			),
			hr()
		),
		fluidRow(
			conditionalPanel(
				condition = "output.showResults == 'yes' ",
				column(6,
							 h4('Summary Information'),
							 hr(),
							 verbatimTextOutput('io.model'),
							 br(),
							 plotOutput('io.varplot'),
							 br(),
							 textOutput('seed.v')
				),
				column(6,
							 h4('Model Accuracy'),
							 hr(),
							 verbatimTextOutput('io.matrix'),
							 br(),
							 plotOutput('io.graphics')
							 
				)
			)
		)
	)
)