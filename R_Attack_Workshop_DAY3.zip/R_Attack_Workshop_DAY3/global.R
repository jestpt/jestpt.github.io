# Pré-processamento essencial

data <- read.csv("data.csv")
data <- data[complete.cases(data),]
machinedata <- data[,-1]

# Modelos de Machine Learning para Classificação 

model.list <- c(
	"Partial Least Squares" = "kernelpls",
	"k-Nearest Neighbors" = "knn",
	"Naive Bayes" = "nb",
	"Linear Discriminant Analysis" = "lda",
	"Flexible Discriminant Analysis" = "fda",
	"Generalized Additive Model using Splines" = "gamSpline",
	"Boosted Logistic Regression" = "LogitBoost",
	"Penalized Logistic Regression" = "plr",
	"Decision Tree" = "rpart",
	"Random Forest" = "rf",
	"Stochastic Gradient Boosting" = "gbm",
	"Neural Network" = "nnet"
)